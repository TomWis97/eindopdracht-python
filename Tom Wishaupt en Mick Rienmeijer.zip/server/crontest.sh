#!/bin/bash
while true; do
  echo "execute!"
  time ./cronscript.py
  sleep 20
done
